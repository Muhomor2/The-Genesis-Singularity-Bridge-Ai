# Kadmon AI Interface

## Overview
This package contains three core components of the **Kadmon AI Interface** system:
1. **kadmon_ai_interface.py** – Python-based core engine with 16 apertures, command parser, and state export.
2. **kadmon_web.html** – Standalone web interface with sliders for all 16 apertures and 3D fractal visualization (Fern-like structure using Three.js).
3. **kadmon_prompter.txt** – Prompt template for AI integration, containing placeholders for aperture values.

---

## Installation & Usage

### 1. Python Core
Run the Python interface to adjust apertures and export states.

```bash
python3 kadmon_ai_interface.py
```

### 2. Web Interface
Open `kadmon_web.html` in any modern browser.  
You will see:
- Sliders for all 16 apertures
- Live 3D fractal visualization
- Export button to save current state as JSON

### 3. AI Prompter
Use `kadmon_prompter.txt` as a base template for integrating aperture values into AI prompts.  
Each placeholder `{{a01}}` … `{{a16}}` will be replaced with the current aperture values.

---

## Future Extensions
- API integration (Flask / FastAPI)
- Real-time WebSocket interface
- Quantum simulation integration (Qiskit)
- NFT or data-art generator

---

**Kadmon Awakens.**
