import json
import math
import random
from dataclasses import dataclass
from typing import Dict, List, Any

@dataclass
class KadmonAIInterface:
    apertures: Dict[str, float]

    def __init__(self):
        self.apertures = {f"a{i:02d}": 0.5 for i in range(1, 17)}

    def execute_commands(self, commands: List[str]):
        for cmd in commands:
            cmd = cmd.strip().lower()
            if "adjust" in cmd and "to" in cmd:
                try:
                    parts = cmd.split()
                    key = parts[1]
                    value = float(parts[-1])
                    if key in self.apertures:
                        self.apertures[key] = max(0.0, min(1.0, value))
                        print(f"{key} adjusted to {value:.2f}")
                except Exception as e:
                    print(f"Error parsing 'adjust': {cmd} — {e}")
            elif "increase" in cmd and "by" in cmd:
                try:
                    parts = cmd.split()
                    key = parts[1]
                    delta = float(parts[-1])
                    if key in self.apertures:
                        new_val = self.apertures[key] + delta
                        self.apertures[key] = max(0.0, min(1.0, new_val))
                        print(f"{key} increased by {delta:.2f} → {self.apertures[key]:.2f}")
                except Exception as e:
                    print(f"Error parsing 'increase': {cmd} — {e}")
            elif "set" in cmd and "luminosity" in cmd:
                base = 0.8
                fluctuation = 0.2 * self.apertures["a05"]
                self.apertures["a10"] = max(0.0, min(1.0, base + fluctuation * 0.5))
                print(f"a10 set for luminosity: {self.apertures['a10']:.2f}")
            elif "export" in cmd:
                return self.export_state()
            else:
                print(f"Unknown command: {cmd}")
        return self.export_state()

    def export_state(self) -> Dict[str, Any]:
        base_points = 10000
        randomness = int(2345 * random.random())
        points_generated = base_points + randomness

        hue = int(self.apertures["a03"] * 360)
        saturation = 80
        lightness = int(self.apertures["a05"] * 100)
        color_scheme = f"HSL({hue}, {saturation}%, {lightness}%)"

        rotation_speed_rpm = round(self.apertures["a11"] * 100, 2)

        return {
            "points_generated": points_generated,
            "color_scheme": color_scheme,
            "rotation_speed_rpm": rotation_speed_rpm,
            "aperture_states": self.apertures.copy()
        }

if __name__ == "__main__":
    kadmon = KadmonAIInterface()
    commands = [
        "adjust a01 to 0.75",
        "increase a04 by 0.1",
        "set a10 for luminosity effect",
        "export state"
    ]
    result = kadmon.execute_commands(commands)
    print(json.dumps(result, indent=2))
